// InputTesting.cpp : Defines the entry point for the application.
//
#include "InputTesting.h"
#define _CRT_SECURE_NO_WARNINGS
#include <Input.h>
#include <cstdio>
#include <iostream>

#include "framework.h"

#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE hInst;                                // current instance
WCHAR szTitle[MAX_LOADSTRING];                  // The title bar text
WCHAR szWindowClass[MAX_LOADSTRING];            // the main window class name

CommonUtilities::InputHandler globalInputHandler;


// Forward declarations of functions included in this code module:
ATOM                MyRegisterClass(HINSTANCE hInstance);
BOOL                InitInstance(HINSTANCE, int);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    About(HWND, UINT, WPARAM, LPARAM);

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
	_In_opt_ HINSTANCE hPrevInstance,
	_In_ LPWSTR    lpCmdLine,
	_In_ int       nCmdShow)
{
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

	// TODO: Place code here.

	// Initialize global strings
	LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadStringW(hInstance, IDC_INPUTTESTING, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);

	// Perform application initialization:
	if (!InitInstance(hInstance, nCmdShow))
	{
		return FALSE;
	}

	HACCEL hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_INPUTTESTING));

	MSG msg;

	// Main message loop:
	while (GetMessage(&msg, nullptr, 0, 0))
	{
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		// TODO: Place test code here.
		//std::cout << "Message ID #" << msg.message << "; " << msg.wParam << "; " << msg.lParam << "\n";

		globalInputHandler.UpdateInput();
		if (globalInputHandler.IsKeyDown(CommonUtilities::KEY_LMB))
		{
			std::cout << "Left mouse spam!\n";
		}
		if (globalInputHandler.IsKeyPressed(CommonUtilities::KEY_RMB))
		{
			std::cout << "Right mouse pressed, initiating mouse-logging mode! Release Right mouse to disable.\n";
		}
		if (globalInputHandler.IsKeyDown(CommonUtilities::KEY_RMB))
		{
			CommonUtilities::Vector2float mP = globalInputHandler.GetMousePosition();
			CommonUtilities::Vector2float md = globalInputHandler.GetMousePositionDelta();
			std::cout << "Mouse Position: [ x: " << mP.x << " I y: " << mP.y << " ]\n";
			std::cout << "Mouse Delta: [ x: " << md.x << " I y: " << md.y << " ]\n";

			CommonUtilities::Vector2float v = globalInputHandler.GetMousePositionDelta();
			std::cout << "Mouse Wheel Change: " << globalInputHandler.GetMouseWheelDelta() << std::endl;
		}
		if (globalInputHandler.IsKeyReleased(CommonUtilities::KEY_RMB))
		{
			std::cout << "Right mouse released, disabling mouse-logging mode.\n";
		}
		if (globalInputHandler.IsKeyPressed(CommonUtilities::KEY_MMB))
		{
			std::cout << "Middle mouse pressing its own cheese!\n";
		}
		if (globalInputHandler.IsKeyDown('W') || globalInputHandler.IsKeyDown('A') || globalInputHandler.IsKeyDown('S') || globalInputHandler.IsKeyDown('D'))
		{
			std::cout << "I'm WASD:ing here!\n";
		}
		if (globalInputHandler.IsKeyPressed('F'))
		{
			std::cout << "Starting respect: (F)\n";

		}
		if (globalInputHandler.IsKeyDown('F'))
		{
			std::cout << "Respecting... (F)\n";

		}
		if (globalInputHandler.IsKeyReleased('F'))
		{
			std::cout << "Ending respect. (F)\n";

		}
		if (globalInputHandler.IsKeyReleased(VK_SPACE))
		{
			std::cout << "Space given space!\n";
		}
	}

	return (int)msg.wParam;
}



//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEXW wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);

	wcex.style = CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc = WndProc;
	wcex.cbClsExtra = 0;
	wcex.cbWndExtra = 0;
	wcex.hInstance = hInstance;
	wcex.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_INPUTTESTING));
	wcex.hCursor = LoadCursor(nullptr, IDC_ARROW);
	wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	wcex.lpszMenuName = MAKEINTRESOURCEW(IDC_INPUTTESTING);
	wcex.lpszClassName = szWindowClass;
	wcex.hIconSm = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

	return RegisterClassExW(&wcex);
}

//
//   FUNCTION: InitInstance(HINSTANCE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{

	// Creates a console window, but doesn't output to it
	AllocConsole();
	freopen("conin$", "r", stdin);
	freopen("conout$", "w", stdout);
	freopen("conout$", "w", stderr);
	printf("Debugging Window:\n");
	printf("Try pressing buttons: Space, Left mouse, Right mouse, Middle mouse, F, & WASD to test functionality!\n");

	hInst = hInstance; // Store instance handle in our global variable

	HWND hWnd = CreateWindowW(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, nullptr, nullptr, hInstance, nullptr);

	if (!hWnd)
	{
		return FALSE;
	}

	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	return TRUE;
}

//
//  FUNCTION: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE: Processes messages for the main window.
//
//  WM_COMMAND  - process the application menu
//  WM_PAINT    - Paint the main window
//  WM_DESTROY  - post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	if (globalInputHandler.UpdateEvents(message, wParam, lParam))
	{
		return 0;
	}

	switch (message)
	{
		case WM_COMMAND:
		{
			int wmId = LOWORD(wParam);
			// Parse the menu selections:
			switch (wmId)
			{
				case IDM_ABOUT:
					DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
					break;
				case IDM_EXIT:
					DestroyWindow(hWnd);
					break;
				default:
					return DefWindowProc(hWnd, message, wParam, lParam);
			}
		}
		break;
		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			BeginPaint(hWnd, &ps);
			// TODO: Add any drawing code here...
			EndPaint(hWnd, &ps);
		}
		break;
		case WM_DESTROY:
			FreeConsole();
			PostQuitMessage(0);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

// Message handler for about box.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
		case WM_INITDIALOG:
			return (INT_PTR)TRUE;

		case WM_COMMAND:
			if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
			{
				EndDialog(hDlg, LOWORD(wParam));
				return (INT_PTR)TRUE;
			}
			break;
	}
	return (INT_PTR)FALSE;
}