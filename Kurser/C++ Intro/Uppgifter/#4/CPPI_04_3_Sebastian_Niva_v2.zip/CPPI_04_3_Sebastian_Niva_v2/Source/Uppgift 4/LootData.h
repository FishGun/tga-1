#pragma once

namespace LootData
{

}