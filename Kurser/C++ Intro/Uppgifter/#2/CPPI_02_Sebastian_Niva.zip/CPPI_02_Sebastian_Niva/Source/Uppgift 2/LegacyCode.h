#pragma once

int PlaySkyHighGame();
